py -3 dnn_mlp.py --dropout_rate 0.95
